# KING OF NIFTY DR. VIKAS LADDHA — Android Admin Demo

A native Android Studio starter project inspired by the supplied admin-panel screenshot.

## Included
- Admin-only demo interface
- Dashboard cards
- New Joining form (name, UPI ID text field, amount, date)
- Members, Investments, Deposits, Withdrawals, Transactions
- Basic Reports and Settings
- Local in-memory demo records

## Important limitations
- This is a **demo project**, not a live investment or payment platform.
- No real UPI collection, bank transfer, deposit, withdrawal, KYC, profit calculation, or customer-fund handling is implemented.
- Demo entries are stored in memory and reset when the app process closes.
- Do not use this app to solicit or accept investments or to make guaranteed-return claims.

## Build APK in Android Studio
1. Install Android Studio and open this project folder.
2. Allow Gradle sync to complete (internet is needed for the Android Gradle Plugin).
3. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. Android Studio will show the generated APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

## Suggested production work (before real deployment)
Use a secure backend, admin authentication with role-based access, encrypted transport, database backups, audit logs, privacy policy, consent, and legally reviewed payment integrations. Never store UPI PINs, OTPs, or banking passwords.

## Build automatically in GitHub Actions (no Android Studio needed)
1. Create a private GitHub repository and upload the contents of this project.
2. Open the repository's **Actions** tab.
3. Select **Build Android APK** and press **Run workflow**.
4. When the workflow finishes, open the run and download the `KING-OF-NIFTY-demo-apk` artifact.
5. Extract the downloaded artifact to get `app-debug.apk`.

This requires a GitHub account and internet access. The workflow builds a debug APK; it is not a signed Play Store release.
