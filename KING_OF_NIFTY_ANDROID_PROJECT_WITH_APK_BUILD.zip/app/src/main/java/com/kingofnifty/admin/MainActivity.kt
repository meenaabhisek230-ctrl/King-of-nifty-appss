package com.kingofnifty.admin

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val blue = Color.rgb(28, 112, 202)
    private val ink = Color.rgb(28, 42, 65)
    private val muted = Color.rgb(105, 119, 139)
    private val bg = Color.rgb(246, 249, 253)
    private lateinit var content: LinearLayout
    private var current = "Dashboard"
    private val members = mutableListOf("Sudarshan sahasrayan khade • ₹5,000 • Demo")
    private val deposits = mutableListOf("Demo deposit • ₹5,000 • Processing")
    private val withdrawals = mutableListOf("No demo withdrawal yet")
    private val transactions = mutableListOf("Demo joining • ₹5,000 • 09/11/2026")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showShell()
        render("Dashboard")
    }

    private fun showShell() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(20, 18, 20, 14); setBackgroundColor(Color.WHITE)
        }
        header.addView(label("KING OF NIFTY", 20, ink, true))
        header.addView(label("DR. VIKAS LADDHA  •  ADMIN DEMO", 11, muted, true))
        root.addView(header)
        val navScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; setBackgroundColor(Color.WHITE) }
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(8, 4, 8, 10) }
        listOf("Dashboard","New Joining","Members","Investments","Deposits","Withdrawals","Transactions","Reports","Settings").forEach { item ->
            val b = Button(this).apply {
                text = item; textSize = 11f; isAllCaps = false
                setTextColor(if (item == current) Color.WHITE else ink)
                setBackgroundTintList(android.content.res.ColorStateList.valueOf(if (item == current) blue else Color.rgb(237,242,248)))
                setOnClickListener { render(item) }
            }
            nav.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, 44).apply { setMargins(4,0,4,0) })
        }
        navScroll.addView(nav); root.addView(navScroll)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 16, 16, 24) }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun render(page: String) {
        current = page
        showShell()
        content.removeAllViews()
        when(page) {
            "Dashboard" -> dashboard()
            "New Joining" -> newJoining()
            "Members" -> listPage("Members", members)
            "Investments" -> listPage("Investments", members)
            "Deposits" -> listPage("Deposits", deposits)
            "Withdrawals" -> listPage("Withdrawals", withdrawals)
            "Transactions" -> listPage("Transactions", transactions)
            "Reports" -> reports()
            "Settings" -> settings()
        }
    }

    private fun dashboard() {
        content.addView(label("Admin Dashboard", 22, ink, true))
        content.addView(label("Demo data only — no real money is moved.", 13, muted, false))
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val row1 = LinearLayout(this)
        row1.addView(statCard("Total Members", members.size.toString()), LinearLayout.LayoutParams(0, 112, 1f))
        row1.addView(statCard("Demo Investments", "₹5,000"), LinearLayout.LayoutParams(0, 112, 1f))
        val row2 = LinearLayout(this)
        row2.addView(statCard("Deposits", deposits.size.toString()), LinearLayout.LayoutParams(0, 112, 1f))
        row2.addView(statCard("Withdrawals", withdrawals.count { !it.startsWith("No ") }.toString()), LinearLayout.LayoutParams(0, 112, 1f))
        grid.addView(row1); grid.addView(row2); content.addView(grid)
        content.addView(section("Quick actions"))
        listOf("New Joining","Members","Deposits","Withdrawals","Transactions","Reports").forEach { item ->
            val b = Button(this).apply { text = item; isAllCaps = false; setOnClickListener { render(item) } }
            content.addView(b)
        }
        content.addView(note("This sample admin app stores demo records only in memory. Records reset when the app is closed."))
    }

    private fun newJoining() {
        content.addView(label("New Joining", 22, ink, true))
        content.addView(label("Add a demo member and record investment details.", 13, muted, false))
        val name = field("Member name")
        val upi = field("UPI ID (optional demo field)")
        val amount = field("Investment amount (₹)")
        val date = field("Investment date (e.g. 11/11/2026)")
        content.addView(formLabel("Member Details")); content.addView(name)
        content.addView(formLabel("UPI ID")); content.addView(upi)
        content.addView(formLabel("Investment Amount")); content.addView(amount)
        content.addView(formLabel("Investment Date")); content.addView(date)
        val save = Button(this).apply {
            text = "Save Demo Member"; isAllCaps = false
            setOnClickListener {
                val n = name.text.toString().trim()
                val a = amount.text.toString().trim()
                if (n.isEmpty() || a.isEmpty() || a.toLongOrNull() == null) {
                    Toast.makeText(this@MainActivity, "Enter member name and valid amount", Toast.LENGTH_SHORT).show()
                } else {
                    members.add("$n • ₹$a • Demo")
                    deposits.add("$n • ₹$a • Demo record")
                    transactions.add("New joining: $n • ₹$a")
                    Toast.makeText(this@MainActivity, "Demo member saved", Toast.LENGTH_SHORT).show()
                    render("Members")
                }
            }
        }
        content.addView(save)
        content.addView(note("UPI ID is collected only as a sample text field. No UPI payment, bank transfer, KYC, or withdrawal is performed."))
    }

    private fun listPage(title: String, data: List<String>) {
        content.addView(label(title, 22, ink, true))
        content.addView(label("Demo records", 13, muted, false))
        data.forEach { content.addView(record(it)) }
        if (data.isEmpty()) content.addView(note("No records yet."))
    }

    private fun reports() {
        content.addView(label("Reports", 22, ink, true))
        content.addView(statCard("Demo members", members.size.toString()))
        content.addView(statCard("Demo investment total", "₹" + members.sumOf { it.substringAfter("₹", "0").substringBefore(" ").toLongOrNull() ?: 0L }))
        content.addView(note("Report values are calculated from local demo entries only."))
    }

    private fun settings() {
        content.addView(label("Settings", 22, ink, true))
        content.addView(record("App: KING OF NIFTY DR. VIKAS LADDHA"))
        content.addView(record("Access: Admin only"))
        content.addView(record("Mode: Demo"))
        content.addView(record("Storage: Temporary local memory"))
        content.addView(note("Before any real deployment, add secure admin authentication, a backend database, audit logs, privacy controls, and legally compliant payment processing. Do not use this demo to collect customer funds or promise investment returns."))
    }

    private fun statCard(title: String, value: String): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(14, 14, 14, 12); setBackgroundColor(Color.WHITE)
        }
        box.addView(label(title, 12, muted, false))
        box.addView(label(value, 22, blue, true))
        val lp = LinearLayout.LayoutParams(-1, 100).apply { setMargins(4, 6, 4, 6) }
        box.layoutParams = lp
        return box
    }

    private fun record(value: String): View {
        val box = TextView(this).apply {
            text = value; textSize = 14f; setTextColor(ink); setPadding(14, 16, 14, 16)
            setBackgroundColor(Color.WHITE)
        }
        val lp = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 5, 0, 5) }
        box.layoutParams = lp
        return box
    }

    private fun field(hintText: String) = EditText(this).apply {
        hint = hintText; textSize = 14f; singleLine = true
        setPadding(14, 12, 14, 12); setBackgroundColor(Color.WHITE)
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        this.text = text; textSize = size.toFloat(); setTextColor(color)
        if (bold) setTypeface(null, Typeface.BOLD)
        setPadding(2, 5, 2, 5)
    }
    private fun section(text: String) { content.addView(label(text, 17, ink, true)) }
    private fun formLabel(text: String) { content.addView(label(text, 13, ink, true)) }
    private fun note(text: String) {
        val v = TextView(this).apply {
            this.text = text; textSize = 12f; setTextColor(muted); setPadding(14, 14, 14, 14)
            setBackgroundColor(Color.rgb(232, 241, 251))
        }
        content.addView(v)
    }
}
